	function fnNumb() {
		var numb = 0;
		$.ajax({ //ajax 실행

			url : "ncs.do", //json url 설정

			success : function(result) {
				var numb = result;

				$('#numb').val(numb.trim());
				$('#numbshow').val(numb.trim());
				$('#numbshow').attr("placeholder", numb.trim());
			}//success
		});//fnNumb

		$("#returnbtn").click(function() {
			location.href = "omrMain.jsp";
		});//click returnbtn
	}//fnNumb()
	
	function fncommit() {
		var subject = $("#subject").val();
		var name = $("#name").val();
		
		if(!subject){
			alert("과목을 선택해주세요");
			return false;
		}else if(!name.trim()){
			alert("이름을 제대로 입력해주세요");
			$("#name").focus();
			return false;
		}else{
			if(!confirm("이대로 응시하시겠습니까?")){
				return false;
			}else{
				return true;
			}//if
		}//if		
	}//fncommit()
	
	function fnreset(){
		if(!confirm("정말로 초기화 하시겠습니까?")){
			return false;
		}else{
			return true;
		}//if
	}//fnreset