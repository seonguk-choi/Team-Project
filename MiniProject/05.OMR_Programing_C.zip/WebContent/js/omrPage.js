	var time = 3000;
	var min = 0;
	var sec = 0;

	function fnStart() {
		min = parseInt(time / 60);
		sec = time % 60;

		time--;
		document.getElementById("time").innerHTML = min + "분" + sec + "초";

		if (time == 0) {
			document.getElementById("time").innerHTML = "시간이 종료되었습니다.";
			document.getElementById("main_form").submit();
		}//if
		setTimeout("fnStart()", 1000);

		$("form").css("display", "block");
		$("#answer").css("display", "block");
		$("#startBtn").css("display", "none");
	}//fnStart
	
	$(document).ready(function() {
		
		$(document).keydown(function (e) {
		     
            if (e.which === 116) {
                if (typeof event == "object") {
                    event.keyCode = 0;
                }
                return false;
            } else if (e.which === 82 && e.ctrlKey) {
                return false;
            }
		}); 

		
		document.getElementById("main_form").onsubmit = function() {		      
		      var numCount = [];
		      for (var i = 0; i < 10; i++) {
		      var t_f = 0;
		         for(var j = 0; j < 4; j++){
		         var num = document.getElementsByName("num" + (i+1))[j];
		         if (num.checked == false) {
		            t_f++;
		         }else if(num.checked == true) {
		            t_f = 0;
		            break;
		         }//if
		         }//for j
		         if(t_f != 0){
		            numCount[i] = (i + 1);      
		         }
		         //alert(num.checked);
		      }//for numc
		      var msg = "";
		      for(var i = 0; i < numCount.length; i++){
		         if(!numCount[i]){
		            
		         }else{
		            msg += numCount[i] + "번 ";
		         }
		      }//for msg
		      
		      if(numCount != 0) {
		         if(confirm(msg + "문제를 풀지 않았습니다. 그래도 제출 하시겠습니까?")){
		            return true;
		         }else {
		         return false;
		         }
		      }else {
		         if(!confirm("이대로 제출 하시겠습니까?")){
		            return false;
		         }else {
		         return true;
		         }
		      }//if
		   }//onsubmit
		
		$(".anwser").change(function() {
			for(var i = 1; i <= 10; i++){
			var length = document.getElementsByName("num" + i).length;
			for (var j = 0; j < length; j++) {
				
			var num = document.getElementsByName("num" + i)[j];
			if(num.checked == true){
				for (var k = 1; k <= length; k++) {
					if(num.value == k){
						$("#omr_answer"+ i).children("label:nth-child("+ k +")").text("●");
						if(k == 1){
							$("#omr_answer"+ i ).children("label:nth-child(2)").text("②");
							$("#omr_answer"+ i ).children("label:nth-child(3)").text("③");
							$("#omr_answer"+ i ).children("label:nth-child(4)").text("④");
						}else if(k == 2){
							$("#omr_answer"+ i ).children("label:nth-child(1)").text("①");
							$("#omr_answer"+ i ).children("label:nth-child(3)").text("③");
							$("#omr_answer"+ i ).children("label:nth-child(4)").text("④");
						}else if(k == 3){
							$("#omr_answer"+ i ).children("label:nth-child(1)").text("①");
							$("#omr_answer"+ i ).children("label:nth-child(2)").text("②");
							$("#omr_answer"+ i ).children("label:nth-child(4)").text("④");
						}else if(k == 4){
							$("#omr_answer"+ i ).children("label:nth-child(1)").text("①");
							$("#omr_answer"+ i ).children("label:nth-child(2)").text("②");
							$("#omr_answer"+ i ).children("label:nth-child(3)").text("③");
						}//if
					}//if
				}//for k
			}//if
			}//for j
			}//for i
		});//change
		
		document.getElementById("main_form").onreset = function(){
			if(confirm("정말로 답안지를 초기화 하시겠습니까?")){
			      for(var i = 1; i <= 10; i++){
				         $("#omr_answer" + i).children("label:nth-child(1)").text("①");
				         $("#omr_answer" + i).children("label:nth-child(2)").text("②");
				         $("#omr_answer" + i).children("label:nth-child(3)").text("③");
				         $("#omr_answer" + i).children("label:nth-child(4)").text("④");
				      }//for
			}else{
				return false;
			}//if
		}//fnReset
	});//ready