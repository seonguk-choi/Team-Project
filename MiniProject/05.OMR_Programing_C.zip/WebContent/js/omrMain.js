
	$(document).ready(function() {
		
		$("#joinTest").click(function() {
			var u_numb = $("#numb").val().trim();
			var u_name = $("#name").val().trim();
			var signal = 1;
			
			if(isNaN(u_numb * 1)){
				alert("수험번호는 숫자만 입력해주세요");
			} else if (!u_numb.trim() || !u_name.trim()) {
				alert("수험번호나 이름이 입력되지 않았습니다");
			} else {
				$.ajax({ //ajax 실행
					url : "tcs.do", 
					type : "POST",
					data : {
						numb : u_numb,
						name : u_name,
						signal : signal
					}, 

					success : function(result) {
						if (result == 0) {
							alert("수험번호나 이름이 잘못입력되었습니다. 다시 입력해주십시요.");
							$("#numb").focus();
						}else if(result == 3) {
							alert("관리자는 시험을 볼 수 없습니다.");
						}else if(result == 2) {
							alert("이미 시험지를 제출하셨습니다");
						} else {
							alert("수험번호와 이름이 제대로 입력되었습니다.");
							location.href = "subcs.do?numb=" + u_numb;
						}//if
					}//success
				});//ajax
			}//iif
		});//click 

		$("#joinAdmin").click(function() {
			var u_numb = $("#numb").val().trim();
			var u_name = $("#name").val().trim();
			var signal = 1;

			if(isNaN(u_numb * 1)){
				alert("수험번호는 숫자만 입력해주세요");
			} else if (!u_numb.trim() || !u_name.trim()) {
				alert("수험번호나 이름이 입력되지 않았습니다");
			} else {
				$.ajax({ //ajax 실행
					url : "tcs.do", 
					type : "POST",
					data : {
						numb : u_numb,
						name : u_name,
						signal : signal
					}, 

					success : function(result) {
						if (result == 0) {
							alert("관리자번호와 이름이 잘못입력되었습니다. 다시 입력해주십시요.");
							$("#numb").focus();
						} else if (result == 3) {
							alert("관리자 페이지로 이동합니다.");
							location.href = "als.do";
						}else {
							alert("관리자 번호와 이름이 아닙니다.");
						}//if
					}//success
				});//ajax 
			}//if
		});//click
		
		$("#TesterScore").click(function() {
			var u_numb = $("#numb").val().trim();
			var u_name = $("#name").val().trim();
			var signal = 2;
			
			if(isNaN(u_numb * 1)){
				alert("수험번호는 숫자만 입력해주세요");
			} else if (!u_numb.trim() || !u_name.trim()) {
				alert("수험번호나 이름이 입력되지 않았습니다");
			} else {
				$.ajax({ //ajax 실행
					url : "tcs.do", 
					type : "POST",
					data : {
						numb : u_numb,
						name : u_name,
						signal : signal
					}, 

					success : function(result) {
						if (result == 0) {
							alert("수험번호나 이름이 잘못입력되었습니다. 다시 입력해주십시요.");
							$("#numb").focus();
						} else if (result == 1) {
							alert("결과 확인 페이지로 이동합니다.");
							location.href = "tpcs.do?numb=" + u_numb;
						} else if (result == 3) {
							alert("아직 합격 확인 기간이 아닙니다");
						} else {
							alert("아직 시험에 응시하지 않았습니다");
						}//if
					}//success
				});//ajax 
			}//if
		});//click joinAdmin
	});//ready