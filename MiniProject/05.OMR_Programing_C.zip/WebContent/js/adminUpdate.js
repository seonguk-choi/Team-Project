$(document).ready(function() {
		if (subject == "정보처리기능사") {
			$("#i_subject1").attr("checked", "checked");
		} else if (subject == "정보처리기사") {
			$("#i_subject2").attr("checked", "checked");
		} else if (subject == "정보처리산업기사") {
			$("#i_subject3").attr("checked", "checked");
		} else {

		}//if subject

		if (state == "미응시") {
			$("#i_state1").attr("checked", "checked");
		} else if (state == "응시") {
			$("#i_state2").attr("checked", "checked");
		} else if (state == "관리자") {
			$("#i_state3").attr("checked", "checked");
		} else {

		}//if state

		if (pass == "합격") {
			$("#i_pass2").attr("checked", "checked");
		} else if (pass == "불합격") {
			$("#i_pass3").attr("checked", "checked");
		} else {
			$("#i_pass1").attr("checked", "checked");
		}//if pass

		$("#returnbtn").click(function() {
			location.href = "als.do";
		});//click returnbtn
				
	});//ready