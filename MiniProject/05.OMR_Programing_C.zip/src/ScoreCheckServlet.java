import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hanul.omr.omrDAO;
import com.hanul.omr.omrDTO;

@WebServlet("/scs.do")
public class ScoreCheckServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		int numb = Integer.parseInt(request.getParameter("numb"));
		String name = request.getParameter("name");
		
		int sign = 0;
		omrDAO dao = new omrDAO();
		omrDTO dto = dao.searchTester(numb); 
		PrintWriter out = response.getWriter();
		
		if(name.contentEquals(dto.getName()) && numb == dto.getNumb()) {
			if(dto.getState().contentEquals("응시")) {
				if(dto.getScore() == 101) {
					sign = 3;
					out.print(sign);
				}else {
					sign = 1;
					out.print(sign);
				}//if				
			}else {
				sign = 2;
				out.print(sign);
			}//if			
		}else{
			sign = 0;
			out.print(sign);
		}//else if
		
	}//service
}//ScoreCheckServlet