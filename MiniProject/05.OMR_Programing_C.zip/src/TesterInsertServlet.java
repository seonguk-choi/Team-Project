import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hanul.omr.omrDAO;
import com.hanul.omr.omrDTO;

@WebServlet("/tis.do")
public class TesterInsertServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		int numb = Integer.parseInt(request.getParameter("numb"));
		String name = request.getParameter("name");
		String state = "미응시";
		String pass = "미채점";
		String subject = request.getParameter("subject");
		int score = 102;
		omrDTO dto = new omrDTO(numb, name, state, pass, subject, score);
		
		omrDAO dao = new omrDAO();
		int ita_succ =dao.insertTesterAnswer(dto.getNumb());
		int it_succ = dao.insertTester(dto);
		
		response.setContentType("text/html; charset=utf-8"); 	//MIME Type
		PrintWriter out = response.getWriter();
		
		if(ita_succ > 0 && it_succ > 0) {
			out.println("<script>alert('시험에 제대로 응시되었습니다.');");
			out.println("location.href='omrMain.jsp'</script>");
		}else {
			out.println("<script>alert('시험에 응시에 실패하였습니다.');");
			out.println("location.href='omrMain.jsp'</script>");
		}//if
	}//service

}//TesterInsertServlet
