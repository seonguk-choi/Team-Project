import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.hanul.omr.omrDAO;

@WebServlet("/ncs.do")
public class NumbCheckServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		omrDAO dao = new omrDAO(); 
		int numb = dao.checkSpareNumb(); 

		
		// ③ 프리젠테이션 로직 : 결과를 응답
		PrintWriter out = response.getWriter();

		out.println(numb); // ajax로 넘겨주기 위한 print 속성
		
	}//service
}//NumbCheckServlet
