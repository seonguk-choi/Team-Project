package com.hanul.omr;

import java.io.Serializable;

public class omrDTO implements Serializable {

	private int numb;
	private String name;
	private String state;
	private String pass;
	private String subject;
	private int score;
	
	public omrDTO(){}

	public omrDTO(int numb, String name, String state, String pass, String subject, int score) {
		super();
		this.numb = numb;
		this.name = name;
		this.state = state;
		this.pass = pass;
		this.subject = subject;
		this.score = score;
	}

	public int getNumb() {
		return numb;
	}

	public void setNumb(int numb) {
		this.numb = numb;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getPass() {
		return pass;
	}

	public void setPass(String pass) {
		this.pass = pass;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public int getScore() {
		return score;
	}

	public void setScore(int score) {
		this.score = score;
	};
	
}//answerDTO
