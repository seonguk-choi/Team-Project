package com.hanul.omr;

import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;


public class omrDAO {

private static SqlSessionFactory sqlMapper;
	
	static {
		try {
		String resource = "com/hanul/mybatis/SqlMapConfig.xml";
		InputStream inputStream = Resources.getResourceAsStream(resource);
		sqlMapper = new SqlSessionFactoryBuilder().build(inputStream);
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("SqlSessionFactory Exception!!!");
		}//try & catch
	}//static(초기화 블럭)
	
	//insert------------------------------------------------------------------
	
	//응시자 추가
	public int insertTester(omrDTO dto) {
			
			SqlSession session = sqlMapper.openSession();
			
			int succ = 0;
			
			succ = session.insert("insertTester", dto);
			
			session.commit();
			
			session.close();

		return succ;				//결과값 리턴
		}//insertTester()
	
	//응시자 시험지 등록
	public int insertTesterAnswer(int numb) {
		
			SqlSession session = sqlMapper.openSession();
			
			int succ = 0;
			
			succ = session.insert("insertTesterAnswer", numb);
			
			session.commit();
			
			session.close();
			
			return succ;				//결과값 리턴
	}//insertTesterAnswer()
	
	//select------------------------------------------------------------------
	
	// 정답 확인용
	public answerDTO searchAnswer(String subject) {

		SqlSession session = sqlMapper.openSession();

		answerDTO a_dto = null;
		a_dto = session.selectOne("searchAnswer", subject);

		session.close();

		return a_dto;
	}// searchAnswer()

	// 남는 수험번호 확인
	public int checkSpareNumb() {
		SqlSession session = sqlMapper.openSession();

		int numb = 1000;
		List<Integer> list = null;

		list = session.selectList("checkSpareNumb");
		int i = 0;
		while (i < list.size()) {

			if (numb == list.get(i)) {
				numb++;
			} else {
				break;
			} // if
			i++;
		} // while

		session.close();

		return numb;
	}// checkSpareNumb()

	// 수험번호 체크
	public int checkNumb(int numb) {
		SqlSession session = sqlMapper.openSession();

		int t_numb = session.selectOne("checkNumb", numb);

		session.close();

		return t_numb;
	}// checkNumber()

	// 응시자 전체 목록 검색
	public List<omrDTO> searchAllTesterList() {

		SqlSession session = sqlMapper.openSession();

		List<omrDTO> Testerlist = null;

		Testerlist = session.selectList("searchAllTesterList");

		session.close();

		return Testerlist;
	}// searchList()

	// 응시자 검색
	public omrDTO searchTester(int numb) {
		SqlSession session = sqlMapper.openSession();

		omrDTO dto = null;

		dto = session.selectOne("searchTester", numb);

		session.close();

		return dto;
	}// searchTester()
	
	//응시자 답 검색
	public TesterAnswerDTO searchTesterAnswer (int numb) {
		
		SqlSession session = sqlMapper.openSession();
		
		TesterAnswerDTO t_dto = null;
		
		t_dto = session.selectOne("searchTesterAnswer", numb);

		return t_dto;
	}//searchTesterAnswer()
	
	//update------------------------------------------------------------------
	
	//응시자 정보 수정
	public int updateTester(omrDTO dto) {
		SqlSession session = sqlMapper.openSession();
		
		int succ = 0;
		
		succ = session.update("updateTester", dto);
		
		session.commit();
		
		session.close();
		
		return succ;			//결과값 succ를 반환
	}//updateTester

	//응시자 상태 변경
	public int updateTesterState(int numb) {
		SqlSession session = sqlMapper.openSession();
		
		int succ = 0;
		
		succ = session.update("updateTesterState", numb);
		
		session.commit();
		
		session.close();
		
		return succ;			//결과값 succ를 반환
	}//updateTesterState
	
	//응시자 점수 채점
	public int updateTesterAnswerScroe(int numb, int score) {
		SqlSession session = sqlMapper.openSession();
		
		omrDTO dto = new omrDTO();
		dto.setNumb(numb);
		dto.setScore(score);
		
		int succ = 0;		//결과 저장용 succ 변수 선언 및 초기화
		
		succ = session.update("updateTesterAnswerScroe", dto);
		
		session.commit();
		
		session.close();
		
		return succ;			//결과값 succ를 반환
	}//updateTesterScroe
	
	//응시자 합격 정보 변경
	public int updateTesterPass(int numb, String pass) {
		
		SqlSession session = sqlMapper.openSession();
		
		omrDTO dto = new omrDTO();
		dto.setNumb(numb);
		dto.setPass(pass);
		
		int succ = 0;		//결과 저장용 succ 변수 선언 및 초기화
		succ = session.update("updateTesterPass", dto);
		
		session.commit();
		
		session.close();
		
		return succ;			//결과값 succ를 반환
	}//updateTesterPass
	
	//응시자 점수 상태 변경
	public int updateTesterScore(int numb, int score) {
		SqlSession session = sqlMapper.openSession();
		
		omrDTO dto = new omrDTO();
		dto.setNumb(numb);
		dto.setScore(score);
		
		int succ = 0;		//결과 저장용 succ 변수 선언 및 초기화
		succ = session.update("updateTesterScore", dto);
		
		session.commit();
		
		session.close();
		
		return succ;			//결과값 succ를 반환
	}//updateTesterScore
	
	public int updateTesterAnswer(TesterAnswerDTO dto) {
		SqlSession session = sqlMapper.openSession();
		
		int succ = 0;		//결과 저장용 succ 변수 선언 및 초기화
		succ = session.update("updateTesterAnswer", dto);
		
		session.commit();
		
		session.close();
		
		return succ;			//결과값 succ를 반환
	}//updateTesterAnswer
	
	//--------------------------------------------------------------------------------------
	public List<Integer> change_t_List(TesterAnswerDTO t_dto) {
		List<Integer> t_answerlist = new ArrayList<>();
		
		t_answerlist.add(t_dto.getNum1());
		t_answerlist.add(t_dto.getNum2());
		t_answerlist.add(t_dto.getNum3());
		t_answerlist.add(t_dto.getNum4());
		t_answerlist.add(t_dto.getNum5());
		t_answerlist.add(t_dto.getNum6());
		t_answerlist.add(t_dto.getNum7());
		t_answerlist.add(t_dto.getNum8());
		t_answerlist.add(t_dto.getNum9());
		t_answerlist.add(t_dto.getNum10());
		t_answerlist.add(t_dto.getScore());
		
		return t_answerlist;
	}//change_t_List
	
	public List<Integer> change_a_List(answerDTO a_dto) {
		List<Integer> answerlist = new ArrayList<>();
		
		answerlist.add(a_dto.getAnswer1());
		answerlist.add(a_dto.getAnswer2());
		answerlist.add(a_dto.getAnswer3());
		answerlist.add(a_dto.getAnswer4());
		answerlist.add(a_dto.getAnswer5());
		answerlist.add(a_dto.getAnswer6());
		answerlist.add(a_dto.getAnswer7());
		answerlist.add(a_dto.getAnswer8());
		answerlist.add(a_dto.getAnswer9());
		answerlist.add(a_dto.getAnswer10());
		
		return answerlist;
	}//change_a_List
	}// answerDAO