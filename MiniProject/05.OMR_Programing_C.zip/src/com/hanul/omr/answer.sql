--정답 테이블 
CREATE TABLE answer_C(
   subject   VARCHAR2(25) PRIMARY KEY not null,
   answer1   NUMBER,
   answer2   NUMBER,
   answer3   NUMBER,
   answer4   NUMBER,
   answer5   NUMBER,
   answer6   NUMBER,
   answer7   NUMBER,
   answer8   NUMBER,
   answer9   NUMBER,
   answer10   NUMBER
  );

--정답 값 입력

INSERT INTO answer_C
VALUES('정보처리기능사', 1, 4, 4, 1, 1, 4, 1, 4, 4, 2);

INSERT INTO answer_C
VALUES('정보처리산업기사', 3, 2, 2, 1, 1, 3, 1, 1, 3, 4);

INSERT INTO answer_C
VALUES('정보처리기사', 3, 2, 1, 1, 3, 3, 2, 2, 4, 4);

--DROP TABLE answer_C PURGE;

-- commit
COMMIT;

-- 조회
SELECT * from answer_C;
select * from answer_C where subject Like '정보처리기능사';

--응시자 테이블 생성
CREATE TABLE Tester_C(
   numb NUMBER PRIMARY KEY not null,
   name  VARCHAR2(20),
   state  VARCHAR2(10),
   pass   VARCHAR2(10),
   subject VARCHAR2(25),
   score NUMBER,
   
  CONSTRAINT Tester_subject_fk FOREIGN KEY (subject) REFERENCES answer_C (subject),
  CONSTRAINT Tester_numb_fk FOREIGN KEY (numb) REFERENCES TesterAnswer_C (numb)       
);

--관리자 삽입
INSERT INTO Tester_C
VALUES(1000, '관리자', '관리자', '관리자', '관리자', '103');

--delete from tester_C where numb > 1000;
--delete from tester_C where numb > 1003;
--DROP TABLE Tester_C PURGE;

-- commit
COMMIT;

-- 조회
SELECT * from Tester_C;

--찍은 답 테이블
CREATE TABLE TesterAnswer_C(
   numb NUMBER PRIMARY KEY not null,
   num1  NUMBER,
   num2  NUMBER,
   num3  NUMBER,
   num4  NUMBER,
   num5  NUMBER,
   num6  NUMBER,
   num7  NUMBER,
   num8  NUMBER,
   num9  NUMBER,
   num10  NUMBER,
   score NUMBER
   
);

COMMIT;

--delete from TesterAnswer_c;
--DROP TABLE TesterAnswer_C PURGE;

-- 조회
SELECT * from TesterAnswer_C;

select numb from Tester_C order by 1;