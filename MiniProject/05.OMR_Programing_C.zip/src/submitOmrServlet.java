import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hanul.omr.TesterAnswerDTO;
import com.hanul.omr.omrDAO;

@WebServlet("/sos.do")
public class submitOmrServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		TesterAnswerDTO dto = new TesterAnswerDTO();
		int numb = Integer.parseInt(request.getParameter("numb"));		
		ArrayList<Integer> list = new ArrayList<Integer>();
		for (int i = 1; i <= 10; i++) {
			try{list.add(Integer.parseInt(request.getParameter("num" + i)));}
			catch (Exception e) {
				list.add(0);
			}//try & catch;
		}//for
		dto.setNumb(numb);
		dto.setNum1(list.get(0));
		dto.setNum2(list.get(1));
		dto.setNum3(list.get(2));
		dto.setNum4(list.get(3));
		dto.setNum5(list.get(4));
		dto.setNum6(list.get(5));
		dto.setNum7(list.get(6));
		dto.setNum8(list.get(7));
		dto.setNum9(list.get(8));
		dto.setNum10(list.get(9));
		dto.setScore(102);
		omrDAO dao = new omrDAO();
		
		int i_succ = dao.updateTesterAnswer(dto);
		
		response.setContentType("text/html; charset=utf-8"); 	//MIME Type
		PrintWriter out = response.getWriter();					//출력스트림
		
		if(i_succ > 0) {
			System.out.println("답 삽입 성공");
			int score = 101;
			int u_succ = dao.updateTesterState(numb);
			int ut_succ = dao.updateTesterScore(numb, score);
			
			if(u_succ > 0 && ut_succ > 0) {
				System.out.println("응시자 상태 수정 성공");
				out.println("<script>alert('시험지 제출을 완료했습니다'); "
						+ " location.href='omrMain.jsp'</script>");
			}else {
				System.out.println("응시자 상태수정 실패");
			}//if
		}else {
			System.out.println("답 삽입 실패");
		}//if
	}//service
}//submitOmrServlet
