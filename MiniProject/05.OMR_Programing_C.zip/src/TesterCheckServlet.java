import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hanul.omr.omrDAO;
import com.hanul.omr.omrDTO;

@WebServlet("/tcs.do")
public class TesterCheckServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		int numb = Integer.parseInt(request.getParameter("numb"));
		String name = request.getParameter("name");
		int signal = Integer.parseInt(request.getParameter("signal"));

		int sign = 0;
		omrDAO dao = new omrDAO();
		int t_numb = dao.checkNumb(numb);
		
		PrintWriter out = response.getWriter();
		

			if(numb == t_numb) {
				omrDTO dto = dao.searchTester(numb);		
				
				if (signal == 1) {
					if (name.contentEquals(dto.getName())) {
						if (dto.getState().contentEquals("관리자")) {
							sign = 3;
							out.println(sign);
						} else if (dto.getState().contentEquals("응시")) {
							sign = 2;
							out.println(sign);
						} else {
							sign = 1;
							out.println(sign);
						} // if stagte
					} else {
						sign = 0;
						out.println(sign);
					} // if name
				} else {
					if (name.contentEquals(dto.getName()) && numb == dto.getNumb()) {
						if (dto.getState().contentEquals("응시")) {
							if (dto.getScore() == 101) {
								sign = 3;
								out.print(sign);
							} else {
								sign = 1;
								out.print(sign);
							} // if score
						} else {
							sign = 2;
							out.print(sign);
						} // if state
					} else {
						sign = 0;
						out.print(sign);
					} // if numb name
				} // if signal
			}else {
				sign = 0;
				out.print(sign);
			}//if numb
	}// service

}// TesterCheckServlet
