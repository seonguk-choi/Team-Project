import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hanul.omr.omrDAO;
import com.hanul.omr.omrDTO;

@WebServlet("/als.do")
public class AdminListServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		omrDAO dao = new omrDAO();
		List<omrDTO> Testerlist = dao.searchAllTesterList();
		
		request.setAttribute("Testerlist", Testerlist);				//list를 바인딩 후
		RequestDispatcher rd = request.getRequestDispatcher("adminPage.jsp");	
		rd.forward(request, response);					//페이지 전환
		
	}//service
}//AdminListServlet
