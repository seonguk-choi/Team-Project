import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hanul.omr.omrDAO;
import com.hanul.omr.omrDTO;

@WebServlet("/tus.do")
public class TesterUpdateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		request.setCharacterEncoding("utf-8");
		omrDTO dto = new omrDTO();
		dto.setNumb(Integer.parseInt(request.getParameter("numb")));
		dto.setName(request.getParameter("name"));
		dto.setState(request.getParameter("state"));
		dto.setPass(request.getParameter("pass"));
		dto.setSubject(request.getParameter("subject"));
		
		omrDAO dao = new omrDAO();
		int succ = dao.updateTester(dto);
		
		response.setContentType("text/html; charset=utf-8"); 	//MIME Type
		PrintWriter out = response.getWriter();
		
		if(succ > 0) {
			out.println("<script>alert('응시자 정보수정이 완료되었습니다.');");
			out.println("location.href='als.do'</script>");
		}else {
			out.println("<script>alert('응시자 정보수정에 실패했습니다.');");
			out.println("location.href='als.do'</script>");
		}//if
	}//service
}//TesterUpdateServlet
