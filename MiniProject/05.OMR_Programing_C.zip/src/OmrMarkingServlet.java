import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hanul.omr.omrDAO;

@WebServlet("/oms.do")
public class OmrMarkingServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		request.setCharacterEncoding("utf-8");
		int numb = Integer.parseInt(request.getParameter("numb"));
		int score = Integer.parseInt(request.getParameter("score"));
		
		omrDAO dao = new omrDAO();
		int s_succ = dao.updateTesterAnswerScroe(numb, score);
		int u_succ = dao.updateTesterScore(numb, score);
		
		String pass = null;
		if(score >= 60 && score <= 100) {
			pass = "합격";
		}else {
			pass = "불합격";
		}//if pass
		
		response.setContentType("text/html; charset=utf-8"); 	//MIME Type
		PrintWriter out = response.getWriter();					//출력스트림
		int p_succ = dao.updateTesterPass(numb, pass);
		
		if(s_succ > 0 && u_succ > 0) {
			if (p_succ > 0) {
				System.out.println("점수 삽입 성공");
				out.println("<script>alert('채점을 완료했습니다.'); "
						+ "location.href='als.do'</script>");
			} else {
				System.out.println("합격 수정 실패");
				out.println("<script>alert('합격 정보 수정을 실패했습니다.'); "
						+ "location.href='als.do'</script>");
			}//if
		}else {
			System.out.println("점수 삽입 실패");
			out.println("<script>alert('채점을 실패했습니다.'); "
					+ "location.href='als.do'</script>");
		}//if		
	}//service
}//OmrMarkingServlet
