$(document).ready(function(){
	
	/*초기화*/
	$("#exit").click(function(){
		if(confirm("시험을 종료하시겠습니까?")== false	) {
			swal ("취소되었습니다.");
			return false;
		}
	});	//reset
   
	//문제 1번 팝업창 켜기
	$("#ex1").click(function(){
        $("#Q1").fadeIn();
    });
    //문제 1번 팝업창 끄기
    $(".exit").click(function() {
        $("#Q1").fadeOut();
    });
    
    //문제 2번 팝업창 켜기
	$("#ex2").click(function(){
        $("#Q2").fadeIn();
    });
    //문제 2번 팝업창 끄기
    $(".exit").click(function() {
        $("#Q2").fadeOut();
    });
    
    //문제 3번 팝업창 켜기
	$("#ex3").click(function(){
        $("#Q3").fadeIn();
    });
    //문제 3번 팝업창 끄기
    $(".exit").click(function() {
        $("#Q3").fadeOut();
    });
    
    //문제 4번 팝업창 켜기
	$("#ex4").click(function(){
        $("#Q4").fadeIn();
    });
    //문제 4번 팝업창 끄기
    $(".exit").click(function() {
        $("#Q4").fadeOut();
    });
    
    //문제 5번 팝업창 켜기
	$("#ex5").click(function(){
        $("#Q5").fadeIn();
    });
    //문제 5번 팝업창 끄기
    $(".exit").click(function() {
        $("#Q5").fadeOut();
    });
    
    //문제 6번 팝업창 켜기
	$("#ex6").click(function(){
        $("#Q6").fadeIn();
    });
    //문제 6번 팝업창 끄기
    $(".exit").click(function() {
        $("#Q6").fadeOut();
    });
    
    //문제 7번 팝업창 켜기
    $("#ex7").click(function(){
        $("#Q7").fadeIn();
    });
    //문제 7번 팝업창 끄기
    $(".exit").click(function() {
        $("#Q7").fadeOut();
    });
    
    //문제8번 팝업창 켜기
    $("#ex8").click(function(){
        $("#Q8").fadeIn();
    });
    //문제 8번 팝업창 끄기
    $(".exit").click(function() {
        $("#Q8").fadeOut();
    });
    
    //문제9번 팝업창 켜기
    $("#ex9").click(function(){
        $("#Q9").fadeIn();
    });
    //문제 9번 팝업창 끄기
    $(".exit").click(function() {
        $("#Q9").fadeOut();
    });
    
    //문제10번 팝업창 켜기
    $("#ex10").click(function(){
        $("#Q10").fadeIn();
    });
    //문제 10번 팝업창 끄기
    $(".exit").click(function() {
        $("#Q10").fadeOut();
    });
    
    //문제11번 팝업창 켜기
    $("#ex11").click(function(){
        $("#Q11").fadeIn();
    });
    //문제 11번 팝업창 끄기
    $(".exit").click(function() {
        $("#Q11").fadeOut();
    });
    
    //문제12번 팝업창 켜기
    $("#ex12").click(function(){
        $("#Q12").fadeIn();
    });
    //문제 12번 팝업창 끄기
    $(".exit").click(function() {
        $("#Q12").fadeOut();
    });
    
    //문제13번 팝업창 켜기
    $("#ex13").click(function(){
        $("#Q13").fadeIn();
    });
    //문제 13번 팝업창 끄기
    $(".exit").click(function() {
        $("#Q13").fadeOut();
    });
    
    //문제14번 팝업창 켜기
    $("#ex14").click(function(){
        $("#Q14").fadeIn();
    });
    //문제 14번 팝업창 끄기
    $(".exit").click(function() {
        $("#Q14").fadeOut();
    });
    
    //문제15번 팝업창 켜기
    $("#ex15").click(function(){
        $("#Q15").fadeIn();
    });
    //문제 15번 팝업창 끄기
    $(".exit").click(function() {
        $("#Q15").fadeOut();
    });
    
    //문제16번 팝업창 켜기
    $("#ex16").click(function(){
        $("#Q16").fadeIn();
    });
    //문제 16번 팝업창 끄기
    $(".exit").click(function() {
        $("#Q16").fadeOut();
    });  
    
    //문제17번 팝업창 켜기
    $("#ex17").click(function(){
        $("#Q17").fadeIn();
    });
    //문제 17번 팝업창 끄기
    $(".exit").click(function() {
        $("#Q17").fadeOut();
    });  
    
    //문제18번 팝업창 켜기
    $("#ex18").click(function(){
        $("#Q18").fadeIn();
    });
    //문제 18번 팝업창 끄기
    $(".exit").click(function() {
        $("#Q18").fadeOut();
    });     
    
    //문제19번 팝업창 켜기
    $("#ex19").click(function(){
        $("#Q19").fadeIn();
    });
    //문제 19번 팝업창 끄기
    $(".exit").click(function() {
        $("#Q19").fadeOut();
    });     
    
    //문제20번 팝업창 켜기
    $("#ex20").click(function(){
        $("#Q20").fadeIn();
    });
    //문제 18번 팝업창 끄기
    $(".exit").click(function() {
        $("#Q20").fadeOut();
    });     
    
});	//document.reday